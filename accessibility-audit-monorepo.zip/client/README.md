# Client

Frontend boundary. Responsible for:
- UI rendering
- client-side navigation
- accessibility semantics and keyboard interaction
- calling the server API

The client must not contain database access or server-only secrets.
