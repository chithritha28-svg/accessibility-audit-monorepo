# Web Accessibility & Architecture Audit

## Audit target
**Website:** https://www.w3.org/  
**Scope:** Public homepage, accessibility/keyboard review, and proposed application architecture.  
**Audit date:** 18 September 2026.

## Deliverables
- `docs/audit-report.md` — audit findings, evidence, priorities, and remediation plan.
- `docs/keyboard-pass.md` — keyboard-only test checklist and recorded observations.
- `docs/architecture.md` — architecture boundaries and first vertical feature slice.
- `docs/architecture-tree.txt` — repository tree.
- `docs/screenshots/` — evidence images included with the submission.
- `client/` — frontend placeholder.
- `server/` — backend placeholder.
- `test/` — test placeholder.
- `docs/` — documentation and audit artifacts.

## Important audit note
This package contains a reproducible Lighthouse command and a documented audit. The execution environment used to generate this package did not have the Lighthouse CLI available and could not reach the target from its local browser/network, so **no Lighthouse score is fabricated**. The report explicitly separates source inspection findings from tests that still need a local Lighthouse run.

## Run locally

### Prerequisites
- Node.js 20+
- npm
- A Chromium-based browser

### Start the skeleton
```bash
npm install
npm run dev
```

### Run Lighthouse
```bash
npm run audit:lighthouse
```

### Run tests
```bash
npm test
```

## Suggested GitHub submission
Create a GitHub repository, copy this folder into it, then:

```bash
git init
git add .
git commit -m "Add accessibility audit and monorepo architecture"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
