These images are submission-ready evidence aids generated with the audit package.

Because the generation environment could not complete a live browser capture of the external target, they are labeled as audit evidence/plans rather than being represented as a live browser screenshot. Replace them with your own Chromium screenshots after running the local keyboard pass and Lighthouse command.
