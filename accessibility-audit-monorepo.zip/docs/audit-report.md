# Accessibility & Architecture Audit Report

## Target
**W3C homepage:** https://www.w3.org/  
**Date:** 18 September 2026

## Standards used
WCAG 2.2 keyboard guidance and W3C accessibility testing guidance were used as the reference framework.

## Lighthouse status

A Lighthouse command is included in the repository:

```bash
npm run audit:lighthouse
```

The generation environment did not have the Lighthouse CLI installed and its local Chromium instance could not retrieve the target website. Therefore, **no Lighthouse score or metric is presented as if it had been measured**. Run the command locally and commit the generated HTML report as `docs/lighthouse-report.html`.

## Five issues / remediation candidates

### 1. No obvious skip-link in the fetched homepage content
**Evidence:** The fetched homepage begins with language-home links and then extensive navigation content before the main `h1` appears later in the document. No visible "Skip to main content" link is present in the fetched content.

**Impact:** Keyboard and screen-reader users may need to traverse repeated navigation before reaching the primary content.

**Priority:** High

**Remediation:** Add a keyboard-visible skip link as the first focusable element, targeting the main content landmark.

### 2. Large navigation surface before primary content
**Evidence:** The homepage exposes multiple navigation groups such as "Standards & groups", "Get involved", "Resources", "News & events", "Support us", and "About" before the main heading.

**Impact:** A large number of focusable links can increase navigation effort for keyboard users.

**Priority:** Medium

**Remediation:** Keep navigation grouped under semantic landmarks, provide a skip link, and ensure focus order is logical. Consider progressive disclosure for secondary navigation where appropriate.

### 3. Generic image alternative text appears in the fetched content
**Evidence:** The fetched page exposes image entries whose accessible text is simply "Image", while another image has a descriptive alternative ("TPAC 2026 ...").

**Impact:** Generic alternatives provide little information to non-visual users when the image conveys meaning.

**Priority:** Medium

**Remediation:** Give informative images concise purpose-based alt text; mark purely decorative images as decorative so they are ignored by assistive technology.

### 4. Embedded video fallback needs an explicit keyboard/accessibility verification
**Evidence:** The homepage includes an embedded video and a fallback link to the MP4 file.

**Impact:** Media controls, captions, focus order, and fallback behavior need keyboard verification. Source presence alone does not prove the media experience is fully accessible.

**Priority:** Medium

**Remediation:** Test all media controls with keyboard only, provide captions/transcript when applicable, verify focus visibility, and ensure the fallback link remains keyboard accessible.

### 5. Dynamic/rotating member-logo content needs motion and focus review
**Evidence:** The homepage text states that member organization logos are rotated randomly.

**Impact:** Automatically changing content can create discoverability and focus-order issues if focusable content changes while a user is navigating.

**Priority:** Medium

**Remediation:** Ensure rotation does not move keyboard focus, provide a mechanism to pause/stop non-essential movement where applicable, and verify that the accessible name/order of the logo links remains stable.

## Architecture observations

### Current public-site architecture signal
The homepage is content-rich and organizes information into multiple topical navigation and content sections. A maintainable implementation should keep repeated navigation, content sections, media, and footer components separate.

### Recommended application architecture
The repository skeleton uses four explicit boundaries:

- `client/` — presentation and keyboard interaction
- `server/` — API and domain logic
- `test/` — automated verification
- `docs/` — audit and architecture evidence

This separation supports an incremental vertical slice without coupling browser code to persistence.

## Remediation plan

| Priority | Item | First action |
|---|---|---|
| High | Skip link / navigation bypass | Add and test skip link |
| Medium | Navigation density | Validate focus order and landmark structure |
| Medium | Generic image alternatives | Audit every meaningful image's alt text |
| Medium | Video accessibility | Keyboard/caption/focus test |
| Medium | Rotating content | Verify focus stability and motion behavior |

## Evidence source
The public W3C homepage was inspected for document structure and visible content. WCAG 2.2 and W3C accessibility guidance were used to define the expected behavior.

## Verification checklist before submission
- [ ] Run Lighthouse locally and commit the HTML report.
- [ ] Perform the keyboard-only pass in Chrome/Chromium.
- [ ] Capture screenshots of every confirmed issue.
- [ ] Add screenshot filenames to the evidence table.
- [ ] Run `npm test`.
- [ ] Push the completed repository to GitHub.
