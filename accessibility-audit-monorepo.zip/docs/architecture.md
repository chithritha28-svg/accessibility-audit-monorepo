# Architecture

## Boundary model

```text
Browser
  |
  v
client/
  |  HTTP/JSON
  v
server/
  |
  +--> business/domain logic
  |
  +--> persistence adapter (future)
  |
  v
Database (future)

docs/  -> documentation only
test/  -> automated tests and quality checks
```

## Responsibilities

| Area | Owns | Must not own |
|---|---|---|
| client | UI, routing, keyboard behavior, API calls | DB credentials, persistence |
| server | API, validation, domain rules | browser-only UI state |
| test | unit/integration/e2e checks | production business logic |
| docs | architecture, audit evidence, setup | executable application logic |

## Local setup

1. Install Node.js 20+.
2. From the repository root run `npm install`.
3. Start the client with `npm run dev`.
4. Start the server with `node server/index.js`.
5. Open the client at `http://localhost:5173`.
6. Run `npm test`.
7. Run `npm run audit:lighthouse`.

## First vertical feature slice: "Run audit"

The first end-to-end feature should prove the boundaries before more features are added.

1. **Client:** user activates the `Run audit` button.
2. **API:** client sends `POST /api/audits` with the target URL.
3. **Server:** validates the URL and creates an audit job.
4. **Domain:** audit service coordinates Lighthouse and keyboard-check metadata.
5. **Persistence:** store audit result and timestamp.
6. **API response:** return `{id, status, targetUrl}`.
7. **Client:** show status using an `aria-live` region.
8. **Test:** verify request validation, successful creation, and accessible status feedback.

## Architectural rules

- Keep API contracts versionable.
- Keep accessibility behavior in reusable client components.
- Prefer semantic HTML before adding ARIA.
- Keep audit execution server-side if Lighthouse is automated.
- Treat audit evidence as immutable artifacts with timestamps.
