# Keyboard-only navigation pass

## Method
Use only:
- `Tab` / `Shift+Tab`
- `Enter`
- `Space`
- arrow keys where a widget requires them
- `Esc` where a dialog/menu requires it

Reference: WCAG 2.2 keyboard requirements state that functionality must be operable through a keyboard interface and that keyboard focus must not become trapped. The W3C accessibility guidance also recommends checking logical tab order, visible focus, and mouse-free operation.

## Recorded review

| Check | Result | Evidence / note |
|---|---|---|
| Page can receive keyboard focus | Reviewable | Public homepage exposes many links and navigation controls in the fetched page structure. |
| Logical tab sequence | Needs browser verification | Source inspection shows substantial repeated navigation before the main heading; a live Tab sequence should be recorded locally. |
| Skip link | Needs verification / remediation candidate | No skip-link text appears at the beginning of the fetched homepage content. |
| Visible focus | Needs browser verification | Cannot truthfully claim a visual-focus pass without a local browser session. |
| All interactive controls keyboard-operable | Needs browser verification | Requires activating each control with keyboard only. |
| Keyboard trap | Needs browser verification | Requires entering/exiting any menus, media controls, or dialogs. |
| Focus after dialogs/popups | Needs browser verification | Requires opening any interactive popup and checking focus return. |

## Reproducible local procedure

1. Open `https://www.w3.org/`.
2. Do not use the mouse.
3. Press `Tab` repeatedly and record each focus target.
4. Check whether a skip-to-main mechanism appears early.
5. Activate menus with `Enter`/`Space`.
6. Enter and exit any dialogs or media controls.
7. Use `Shift+Tab` to confirm reverse navigation.
8. Capture screenshots at each failure.
9. Save the notes beside this file.

**Important:** The package does not claim that an unobserved keyboard failure occurred. Items marked "Needs browser verification" are deliberately separated from source-based findings.
