const assert = require('assert');
assert.strictEqual(1 + 1, 2);
console.log('Smoke test passed.');
