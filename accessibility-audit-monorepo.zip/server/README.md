# Server

Backend boundary. Responsible for:
- HTTP API
- validation
- business rules
- persistence adapters

The server should expose stable API contracts to the client and keep database credentials private.
